/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package stubForEntity;

import model_interface.Entity;

/**
 *
 * @author Giga P34
 */
public class EntityFactoryStub {

}
